#!/bin/bash

zip -r "BotAutoLogin.zip" * -x "BotAutoLogin.zip"